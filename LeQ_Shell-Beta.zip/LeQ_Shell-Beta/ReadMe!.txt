Hello The Creator Straight#7171 Here!

----------------------------------------
Name: LeQ_Shell
Author/Creator: Straight#7171
type: Console_App
ext: .exe
Language: C#
Threat: None

----------------------------------------
About:
LeQ Is A Command-Line-Console Which With Customized Commands You Could Say Its A Modified Version Of Cmd Please Dm The Creator And Tell Him What You Liked And Dint So I Can Modify It Please Do That As That Will Considerably Help Me Also Thank You For Download It!

--Sincerely Straight.

